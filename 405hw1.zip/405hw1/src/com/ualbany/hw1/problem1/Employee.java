package com.ualbany.hw1.problem1;

public class Employee {
	private String firstn;
	private String lastn;
	private double salary;
	
	public Employee(String fname, String lname, double sal) {
		firstn = fname;
		lastn = lname;
		salary = sal;
		if(sal < 0) {salary =0.0;}
	}
	
	public String getFirstName() {
		return firstn;
	}
	public void setFirstName(String fname) {
		firstn = fname;
	}
	public String getLastName() {
		return lastn;
	}
	public void setLastName(String lname) {
		lastn = lname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double s) {
		salary = s;
	}
}
