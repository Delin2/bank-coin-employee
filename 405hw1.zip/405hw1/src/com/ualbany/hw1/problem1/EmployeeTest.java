package com.ualbany.hw1.problem1;

public class EmployeeTest {

	public static void main(String[] args) {
		Employee e1 = new Employee("Sang-hyeok", "Lee", 9001);
		Employee e2 = new Employee("Yiliang", "Peng", 1000);
		double sal1 = e1.getSalary();
		double sal2 = e2.getSalary();
		
		//print employees name and salary
		System.out.println(e1.getFirstName() + " " + e1.getLastName() + 
				" yearly salary of: " + (sal1*12));
		System.out.println(e2.getFirstName() + " " + e2.getLastName() + 
				" yearly salary of: " + (sal2*12));
		
		//Gets 10% raise
		sal1 = 1.1*sal1;
		sal2 = 1.1*sal2;
		System.out.println(e1.getFirstName() + " " + e1.getLastName() + "yearly salary after 10% raise: " + (sal1*12));
		System.out.println(e2.getFirstName() + " " + e2.getLastName() + "yearly salary after 10% raise: " + (sal2*12));
	}

}
