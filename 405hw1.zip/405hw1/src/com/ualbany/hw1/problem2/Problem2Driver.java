package com.ualbany.hw1.problem2;
import java.util.Scanner;

public class Problem2Driver {

	public static void main(String[] args) {
		HW1Problem2 hw1 = new HW1Problem2();
		int n1=0, n2=0;
		int t=10;
		System.out.println("Enter two numbers please:");
		Scanner s = new Scanner(System.in);
		n1 = s.nextInt();
		n2 = s.nextInt();
		System.out.println("Multiple function Result: " + hw1.multiple(n1, n2));
		System.out.println("Enter a number:");
		n1 = s.nextInt();
		System.out.println("Result of the remainder function: " + hw1.remainder(n1));
		double d1,d2,d3,d4;
		System.out.println("Please enter four numbers");
		d1 = s.nextInt();
		d2 = s.nextInt();
		d3 = s.nextInt();
		d4 = s.nextInt();
		System.out.println("Result of the distance function: " + hw1.distance(d1, d2, d3, d4));
		s.close();
		System.out.println("Number of heads from 10 coin flips: " + hw1.coin());
	}

}
