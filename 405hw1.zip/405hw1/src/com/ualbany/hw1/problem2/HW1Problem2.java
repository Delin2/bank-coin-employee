package com.ualbany.hw1.problem2;
import java.util.Random;

public class HW1Problem2 {

	public HW1Problem2() {
		
	}
	
	public boolean multiple(int n1, int n2) {
		if(n1%n2 != 0)
			return false;
		else
			return true;
	}
	
	public int remainder(int n1) {
		return (n1%7);
	}
	//using the hypot function that does the pythagorean formula for us
	public double distance(double x1, double y1, double x2, double y2) {
		return Math.hypot(x1-x2, y1-y2);
	}
	//coin flip simulator
	//returns the number of heads
	public int coin() {
		Random rand = new Random();
		int heads = 0;
		for(int i=0; i<10; i++) {
			int n = rand.nextInt(2);
			if(n == 1) {heads++;}
		}
		return heads;
	}
}
