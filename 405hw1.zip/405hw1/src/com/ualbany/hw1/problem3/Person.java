package com.ualbany.hw1.problem3;

public class Person {

	private String name;
	private Address addr;
	
	public Person(String fname, String lname, Address ad)
	{
		name = (fname + " " + lname);
		addr = ad;
	}
	public String getName() {
		return name;
	}
}
