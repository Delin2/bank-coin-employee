package com.ualbany.hw1.problem3;

public class Address {

	private String line1;
	private String line2;
	private String city;
	private String state;
	private int zip;
	
	public Address(String ln1, String ln2, String ci, String st, int zi) {
		line1 = ln1;
		line2 = ln2;
		city = ci;
		state = st;
		zip = zi;
	}
	
	public String addToString() {
		return (line1 + "\n" + line2 + "\n" + city + ", " + state + " " + zip);
	}
}
