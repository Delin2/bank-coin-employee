package com.ualbany.hw1.problem3;

public class Bank {

	private String name;
	private Address addr;
	
	public Bank(String na, Address ad) {
		name = na;
		addr = ad;
	}
	public String getName()
	{
		return name;
	}
	public static void main(String[] args) {
		Address bank = new Address("54321", "octoland", "Kraken", "Undadasea", 00001);
		Bank b = new Bank("Mother of Pearl Bank", bank);
		Address person = new Address("Hell", "Fire", "Red Valley", "Amazon", 666);
		Person p = new Person("Dilly", "McPickle", person);
		System.out.println("Dilly McPickle entered " + b.getName());
		CheckingBankAccount cba = new CheckingBankAccount();
		double curr = cba.deposit(1000);
		System.out.println("\nDeposit Reciept of 1000\nDilly McPickle\n" + person.addToString() +
				"\nCurrent balance: " + curr);
		curr = cba.widthdraw(500);
		System.out.println("\nWidthdrawal Reciept of 500\nDilly McPickle\n" + person.addToString() +
				"\nCurrent balance: " + curr);
	}

}
