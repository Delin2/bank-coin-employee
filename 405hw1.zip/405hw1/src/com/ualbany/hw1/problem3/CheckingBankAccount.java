package com.ualbany.hw1.problem3;

public class CheckingBankAccount {

	private double value;
	
	public CheckingBankAccount() {
		
	}
	public double deposit(double n) {
		value += n;
		return value;
	}
	public double widthdraw(double n) {
		value -= n;
		return value;
	}
}
